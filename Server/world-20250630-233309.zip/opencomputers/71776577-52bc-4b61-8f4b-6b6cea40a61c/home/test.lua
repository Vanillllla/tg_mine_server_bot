local component = require("component")
local modem = component.modem

print("Write message: ")

while true do
  modem.broadcast(1, io.read())
end