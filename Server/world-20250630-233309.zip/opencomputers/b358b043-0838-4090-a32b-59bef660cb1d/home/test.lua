local component = require("component")
local computer = require("computer")
local event = require("event")
local modem = component.modem
local number = 0

modem.open(1)

while true do
  number = number + 1
  print("Wait...")
  local e = {event.pull('modem_message')}
  print("Message "..number.."\n")
  for a, b in ipairs(e) do
    print(a.." "..tostring(b))
  end
  print(" ")
end